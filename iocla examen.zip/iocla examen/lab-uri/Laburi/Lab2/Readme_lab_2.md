# Lab 2

Programe ```C``` scrise folosind doar ```if```-uri si ```goto``` si, acolo unde este cazul, alocare dinamica de memorie

## KMP_goto

- algoritmul Knuth-Morris-Pratt

- datele se citesc din fisierul ```strmatch.in``` si se scriu in fisierul ```strmatch.out```

## bin_search

- cautare binara pe biti (cu shiftari)

- inputul se citeste de la ```stdin``` si se scrie la ```stdout```

## bubble_sort

- sortarea unui vector in ```O(kn)```
```k``` = numarul de inversiuni din vector

## max_vect

- maximul dintr-un vector... nimic deosebit

## warm-up-gotos

- bogosort randomizand folosind ```rand()```

- [best code comments](http://stackoverflow.com/questions/184618/what-is-the-best-comment-in-source-code-you-have-ever-encountered)
